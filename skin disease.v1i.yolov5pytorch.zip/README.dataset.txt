# skin disease > 2023-10-04 6:45pm
https://universe.roboflow.com/fredrick-gk-wpenz/skin-disease-hwlrn

Provided by a Roboflow user
License: CC BY 4.0

